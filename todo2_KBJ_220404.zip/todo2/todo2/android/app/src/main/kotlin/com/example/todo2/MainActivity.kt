package com.example.todo2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
